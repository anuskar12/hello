import java.util.Scanner;
import java.util.ArrayList;
import java.util.Iterator;
public class ArrayListExampleCopy{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<String> name=new ArrayList<>();
        //using add() method
        name.add("Test1");
        name.add("Test2");
        name.add(1,"testp1");
        name.remove(1);
        //name.clear();
        //using size() 
        System.out.println(name.size());
        System.out.println(name);
        System.out.println("-----accessing the elements using for each loop");
        for(String st:name){
            System.out.print(st+"  ");
        }
        System.out.println("-----accessing the elements using Iterator Interface");
        Iterator itr=name.iterator();
        
         //hasNext(), next(), clear();
        while(itr.hasNext()){
           itr.remove();
            System.out.print(itr.next()+"  ");
        }

        scanner.close();     
        
    }

    
}
