public class Customer{
   int customerId;
   String name;
   String email;
   String address;
   public Customer(int customerId, String name, String email, String address){
       this.customerId=customerId;
       this.name=name;
       this.email=email;
       this.address=address;
   }
}