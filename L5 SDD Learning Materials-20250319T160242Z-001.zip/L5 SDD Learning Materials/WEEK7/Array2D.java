//Write a java program to find the larget elements of 2x2 matrix.
//create 2D array
//Enter the elements of matrix from the keyboard
//find the largest element from the matrix
//display the largest number. 
import java.util.Scanner;
public class Array2D{
   public static void main(String[] args){
       int[][] arr=new int[2][2];
       Scanner sc=new Scanner(System.io);
       //accepting the arrya elements from the user
       for(int i=0;i<2;i++){
         System.out.println("Enter any two elements for "+(i+1)+" row");
         for(int j=0;j<2;j++){
            arr[i][j]=sc.nextInt();
         }
       }
       //find the largest element from the matrix
       int largest=0;
       for(int i=0;i<2;i++){
         for(int j=0;j<2;j++){
            if(largest<arr[i][j]){
               largest=arr[i][j]
            }
         }
       }
       System.out.println("Largest element of the array= "+largest);
   }
}