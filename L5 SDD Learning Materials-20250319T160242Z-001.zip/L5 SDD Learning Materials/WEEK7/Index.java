import java.util.*;
public class Index{
   public static void main(String[] args){
      ArrayList<Customer> clist=new ArrayList<>();
      //create the object of Customer class;
      Customer c1=new Customer(1001, "Sabin", "sabin@gmail.com", "Pokhara");
      clist.add(c1);
      Customer c2=new Customer(1002, "Jeni", "jeni@gmail.com", "Kathmandu");
      clist.add(c2);
      Customer c3=new Customer(1003, "Rabin", "rabin@gmail.com", "Chitwan");
      clist.add(c3);
      //display the value of arrayList. 
      Iterator itr=clist.iterator();
      System.out.println("C.Id \t Name\t Email \t address");
      while(itr.hasNext()){
         Customer c=(Customer)itr.next();
         System.out.print(c.customerId + "\t" + c.name + "\t" + c.email + "\t" +c.address);
	 System.out.println();
      }




   
      
   }
}



