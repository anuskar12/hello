import java.util.Scanner;
import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListExample{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Integer intObj = Integer.valueOf(10);
      
        ArrayList<String> name=new ArrayList<>();
        name.add("Test1");
	name.add("Test2");
	name.add("Test3");
        /*
        for(int i=0;i<=3;i++){
           System.out.println("Enter a text: ");
           String s=scanner.nextLine();
           name.add(s);
        }
        */
        //enhanced for loop
        for(String st:name){
             System.out.println(st);
        }
        
        System.out.println("------Using Iterator-----");
        Iterator i=name.iterator();
        while(i.hasNext()){
           System.out.println(i.next());
        }
         
        //using Iterator;
        System.out.println(name.size());
        System.out.println(name);
        name.remove(0);
        System.out.println(name);
        //System.out.println(name.size());
        scanner.close();        
        
    }

    
}
