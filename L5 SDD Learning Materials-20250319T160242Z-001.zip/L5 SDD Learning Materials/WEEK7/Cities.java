import java.util.ArrayList;
public class Cities{
     public static void main(String[] args){
          ArrayList<String> cityList=new ArrayList<>();
          cityList.add("KTM");
          cityList.add("PKH");
          String allCity="";
          for(String city:cityList){
             allCity=allCity+"  "+city;
          }
          System.out.println(allCity);
     }
}