public class CheckEvenOdd{
   public static void main(String []args){
     int n=10;
     CheckEvenOdd obj=new CheckEvenOdd();
     obj.isEven(n);
   }
   public void isEven(int num){
      if(num%2==0)
         System.out.println(num+" is even");
      else
         System.out.println(num+" is odd");
   }
}