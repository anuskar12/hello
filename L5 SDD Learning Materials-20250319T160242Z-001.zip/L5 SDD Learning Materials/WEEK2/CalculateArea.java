public class CalculateArea{
   public int area(int l, int b){
     return l*b;
   }
   public float area(float r){
       final float PI=3.14f;    
       return PI*r*r;
   }
   public float area(int a, int b, int h){
      float a=0.5*(a+b)*h;
      return a;
   }
   public static void main(String []args){
      CalculateArea obj=new CalculateArea();
      System.out.println("Area of Rectangle= "+obj.area(5,6);
      System.out.println("Area of Circle= "+obj.area(1.5f);
      System.out.println("Area of trapezium= "+obj.area(4, 6, 2);      

   }
}