//week_2 Tutorial
//Q1. 
public class Week2{
    public static void main(String []args){
        Week2 obj=new Week2();
        obj.greet();
    }
    
    public void greet(){
        System.out.println("Hello! welcome to Java.");
    }

}