public class MTable{
  public static void main(String[] args){
     int x=6;
     MTable obj=new MTable(); 
     obj.multiplicationTable(x);
  }
  //define method to display the multiplication table
  public void multiplicationTable(int n){
    int i;      
    for(i=1;i<=10;i++){
       System.out.println(n+" x "+i+" = "+n*i);
    }
  }
}