import java.util.Scanner;

public class Array2DExample{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
    
        // Ask the user for the number of countries
        System.out.print("Enter the number of countries: ");
        int n = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        // Declare a 2D array to store country-capital pairs
        String[][] countryCapital = new String[n][2];

        // Take user input for country and capital
        for (int i = 0; i < n; i++) {
            System.out.print("Enter country " + (i + 1) + ": ");
            countryCapital[i][0] = scanner.nextLine();

            System.out.print("Enter capital of " + countryCapital[i][0] + ": ");
            countryCapital[i][1] = scanner.nextLine();
        }

        // Close the scanner
        scanner.close();

        // Display the stored country-capital pairs
        displayCountryCapital(countryCapital);
    }

    // Method to display country and capital
    public static void displayCountryCapital(String[][] data) {
        System.out.println("\nList of Countries and Their Capitals:");
        System.out.println("-------------------------------------");
        System.out.printf("%-20s %-20s\n", "Country", "Capital");
        System.out.println("-------------------------------------");

        for (String[] entry : data) {
            System.out.printf("%-20s %-20s\n", entry[0], entry[1]);
        }
    }
}
