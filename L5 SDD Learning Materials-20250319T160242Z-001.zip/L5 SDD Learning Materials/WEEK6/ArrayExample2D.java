import java.util.Scanner;
public class ArrayExample2D{
    public static void main(String[] args){
       int[][] A=new int[2][3];
       int[][] B=new int[2][3];
       int[][] sum=new int[2][3];
       Scanner sc=new Scanner(System.in);
       System.out.println("Enter the elements for matrix A: ");
       for(int i=0;i<2;i++){
         System.out.println("Enter the value for row: "+(i+1));
         for(int j=0;j<3;j++){
	      System.out.print("value for A["+i+"]["+j+"]: ");
              A[i][j]=sc.nextInt();
	      System.out.println();
         }
         System.out.println();
        }
       //asking the elements for B matrix:
       System.out.println("Enter the elements for matrix B: ");
       for(int i=0;i<2;i++){
         System.out.println("Enter the value for row: "+(i+1));
         for(int j=0;j<3;j++){
	      System.out.print("value for B["+i+"]["+j+"]: ");
              B[i][j]=sc.nextInt();
	      System.out.println();
         }
         System.out.println();
       }
       //adding the matrix: 
       for(int i=0;i<2;i++){
         for(int j=0;j<3;j++){
	      sum[i][j]=A[i][j]+B[i][j];
	 }
       }
       //display the result the matix:
       System.out.println("----------SUM of Matrix------------");
       for(int i=0;i<2;i++){
         for(int j=0;j<3;j++){
	      System.out.print(sum[i][j]+" ");
	 }
         System.out.println();
       }
     }
}







