public class StringMethodsDemo{
    public static void main(String[] args) {
        // String Initialization
        String str = "Hello, World!";
        String str2 = "  Java Programming  ";
        String str3 = "hello, world!";
        String str4 = "Java,Python,C++,JavaScript";
        
        // charAt()
        System.out.println("charAt(1): " + str.charAt(1));

        // compareTo() and compareToIgnoreCase()
        System.out.println("compareTo: " + str.compareTo(str3));
        System.out.println("compareToIgnoreCase: " + str.compareToIgnoreCase(str3));

        // concat()
        System.out.println("concat(): " + str.concat(" Welcome!"));

        // contains()
        System.out.println("contains('World'): " + str.contains("World"));

        // equals() and equalsIgnoreCase()
        System.out.println("equals(): " + str.equals(str3));
        System.out.println("equalsIgnoreCase(): " + str.equalsIgnoreCase(str3));

        // startsWith() and endsWith()
        System.out.println("startsWith('Hello'): " + str.startsWith("Hello"));
        System.out.println("endsWith('!'): " + str.endsWith("!"));

        // length()
        System.out.println("length(): " + str.length());

        // indexOf() and lastIndexOf()
        System.out.println("indexOf('o'): " + str.indexOf('o'));
        System.out.println("lastIndexOf('o'): " + str.lastIndexOf('o'));

        // substring()
        System.out.println("substring(7): " + str.substring(7));
        System.out.println("substring(0,5): " + str.substring(0, 5));

        // replace() and replaceAll()
        System.out.println("replace('World', 'Java'): " + str.replace("World", "Java"));
        System.out.println("replaceAll('o', '0'): " + str.replaceAll("o", "0"));

        // toUpperCase() and toLowerCase()
        System.out.println("toUpperCase(): " + str.toUpperCase());
        System.out.println("toLowerCase(): " + str.toLowerCase());

        // trim()
        System.out.println("trim(): '" + str2.trim() + "'");

        // split()
        String[] words = str4.split(",");
        System.out.print("split(): ");
        for (String word : words) {
            System.out.print(word + " | ");
        }
        System.out.println();

        // isEmpty()
        System.out.println("isEmpty(): " + str.isEmpty());

        // valueOf()
        int num = 100;
        System.out.println("valueOf(num): " + String.valueOf(num));
    }
}
