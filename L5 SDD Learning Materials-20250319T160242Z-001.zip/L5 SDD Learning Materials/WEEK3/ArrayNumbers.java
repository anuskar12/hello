//to find the largest number from the array. 
import java.util.Scanner;
public class ArrayNumbers{
   public static void main(String []args){
       int num[]=new int[10];
       Scanner sc=new Scanner(System.in);
       System.out.println("Enter any 10 numbers: ");
       //store the input numbers in array.
       for(int i=0;i<=9;i++){
          num[i]=sc.nextInt();
       }
       int largestNumber=new ArrayNumbers().findLargest(num);
       System.out.println("Largest Numebr= "+largestNumber);       
   }
   //method to find the largest number from the array.
   public int findLargest(int arr[]){
       int largest=arr[0];
       //inhanced loop
       for(int i:arr){
          if(largest < arr[i]){
              System.out.println(arr[i]);
              largest=20;
          }
	  
          
       }
       return largest; 
   }
}







