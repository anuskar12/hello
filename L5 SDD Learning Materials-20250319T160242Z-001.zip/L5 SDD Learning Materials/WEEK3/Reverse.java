import java.util.Scanner;
public class Reverse{
   public static void main(String []args) throws Exception{
       Scanner sc=new Scanner(System.in);
       System.out.println("Enter the text: ");
       String str=sc.nextLine();
       Reverse obj=new Reverse();
       String result=obj.reverseString(str);
       System.out.println("resverse of "+str+" is "+result);
       sc.close();

   }
   public String reverseString(String s){
        char[] charArray = s.toCharArray();
        String reversed = "";
        for (int i = charArray.length - 1; i >= 0; i--) {
            reversed += charArray[i];
        }
        return reversed;
   }
}