//to sort the array elements. 
import java.util.Scanner;
public class ArraySort{
   public static void main(String []args){
       int num[]=new int[5];
       Scanner sc=new Scanner(System.in);
       System.out.println("Enter any 5 numbers: ");
       //store the input numbers in array.
       for(int i=0;i<=4;i++){
          num[i]=sc.nextInt();
       }
       //method call
       ArraySort obj=new ArraySort();
       obj.arraySort(num);
         
   }
   //method to sort the array elements.
   public void arraySort(int arr[]){
       int temp=0;
       for(int i=0;i<arr.length;i++){
          for(int j=i+1;j<arr.length;j++){
              if(arr[i]>arr[j]){
                temp=arr[i];
                arr[i]=arr[j];
                arr[j]=temp;
              }
          }
       }
       //print the sorted array.
       for(int i:arr){
         System.out.print(i+ ", ");
       }
   }
}



















