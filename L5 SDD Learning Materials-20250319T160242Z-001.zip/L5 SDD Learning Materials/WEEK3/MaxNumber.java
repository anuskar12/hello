import java.util.Scanner;
public class MaxNumber{
   public static void main(String []args){
        int a,b;
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter 1st Number: ");
        a=sc.nextInt();
        System.out.print("Enter 2nd Number: ");
        b=sc.nextInt();
        MaxNumber obj=new MaxNumber();
        int max=obj.findMax(a,b);
        //int max=new MaxNumber().findMax(a,b);
        System.out.println("Maximum Number is "+max);        
   }
   public int findMax(int a, int b){
       if(a>b)
         return a;
       else
         return b;
   }
}