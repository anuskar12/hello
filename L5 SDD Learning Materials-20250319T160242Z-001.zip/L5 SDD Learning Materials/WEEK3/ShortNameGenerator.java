import java.util.Scanner;
public class ShortNameGenerator{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Accept full name from user
        System.out.print("Enter full name: ");
        String fullName = scanner.nextLine().trim();
	fullName.toUpperCase();
        
        // Generate short name without using 
        String shortName = ""+fullName.charAt(0);
                
        for (int i = 0; i < fullName.length(); i++) {
            char ch = fullName.charAt(i);
             if(ch == ' ') {
                shortName = shortName+fullName.charAt(i+1);
            }
        }
        
        // Display result
        System.out.println("Short Name: " + shortName);
        
        scanner.close();
    }
}
