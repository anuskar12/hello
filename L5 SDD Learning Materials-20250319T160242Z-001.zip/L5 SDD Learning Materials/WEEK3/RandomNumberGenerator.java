import java.util.Random;

public class RandomNumberGenerator{
    public static void main(String[] args) {
        int[] randomNumbers = generateRandomNumbers(5);
        displayArray(randomNumbers);
    }

    public static int[] generateRandomNumbers(int size) {
        Random rand = new Random();
        int[] numbers = new int[size];

        for (int i = 0; i < size; i++) {
            numbers[i] = rand.nextInt(100) + 1; // Generates numbers between 1 and 100
        }
        return numbers;
    }

    public static void displayArray(int[] array) {
        System.out.print("Random Numbers: ");
        for (int num : array) {
            System.out.print(num + " ");
        }
    }
}
