import java.util.Scanner;
public class StringImmutable{
    public static void main(String[] args) {
        String s="Hello";  
        String s1=new String("my text");

	System.out.println(s);
        System.out.println(s1);
        
    }
}
