public class Student{
    String name;
    int rollNo;
    String grade;
    //using constructor to assign the value for class level variable
    public Student(String name, int rollNo, String grade){
	this.name=name;
        this.rollNo=rollNo;
	this.grade=grade;
    }
    //main method
    public static void main(String []args){
      Student s1=new Student("Sabin", 102, "Class-9");
      Student s2=new Student("Jeni", 103, "12 Management");
      s1.displayDetails();
      s2.displayDetails();
    }
    public void displayDetails(){
        System.out.println("Name= "+this.name);
 	System.out.println("Roll No:= "+this.rollNo);
	System.out.println("Class= "+this.grade);
	System.out.println("");
    }

}