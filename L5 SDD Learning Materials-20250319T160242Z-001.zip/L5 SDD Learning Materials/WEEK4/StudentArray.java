import java.util.Scanner;
public class StudentArray{
   String name;
   int rollNo;
   String grade;
   public StudentArray(String name, int rollNo, String grade){
       this.name=name;
       this.rollNo=rollNo;
       this.grade=grade;
   }
   public static void main(String []args){
      System.out.println("Enter the number of student");
      Scanner sc=new Scanner(System.in);
      int n=sc.nextInt();
      sc.nextLine();
      //<dataype> <variablename>[]=new datatype[n];
      StudentArray students[]=new StudentArray[n];
      // Getting input from user
       for(int i = 0; i < n; i++) {
            System.out.print("Enter name: ");
            String name = sc.nextLine();
            System.out.print("Enter roll number: ");
            int rollNo = sc.nextInt();
	    sc.nextLine();
            System.out.print("Enter grade: ");
            String grade = sc.nextLine();
            sc.nextLine(); 
            StudentArray s=new StudentArray(name, rollNo, grade);
            students[i] = s;
            
        }
        //display the students information: 
        int i=1;
	System.out.println("S.No. \t Name\t\t Roll No.\t Grade");
        for(StudentArray s:students){
             System.out.println(i+"\t"+s.name+"\t"+s.rollNo+"\t"+s.grade);
             i++

        }
        sc.close();

   }
}