public class MenuDriven{
    public static void main(String []args){
        int n=4;
        int a=80;
        int b=40;
        switch(n){
           case 1:                
                System.out.println("Adding......");
                System.out.println("Sum= "+(a+b));
                break;
            case 2:
                System.out.println("Subtracting......");
                System.out.println("Difference= "+(a-b));
                break;
            case 3:
                System.out.println("Multiplying......");
                System.out.println("Product= "+(a*b));
                break;
           case 4:
                System.out.println("Dividing......");
                System.out.println("Quotient= "+(a/b));
                break;
           case 5:
                System.out.println("finding remainder......");
                System.out.println("Remainder= "+(a%b));
                break;
           case 6:
                System.out.println("Exiting....");
                System.exit(0);
           default:
                 System.out.println("Invalid choice");
                 break;
             
            
        }
       
    }
}