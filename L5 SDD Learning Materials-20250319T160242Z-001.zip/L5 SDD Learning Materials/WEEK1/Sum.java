public class Sum{
   public static void main(String[] args){
       int a=8;
       int b=10;
       int s=a+b; 
       System.out.println("sum="+s);
   }
}