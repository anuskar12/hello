public class Books{
   public static void main(String[] args){
      System.out.println("Java Programming");
   }
}